# Chipmunk: A simple webapp develeped using docker

## Development

```
docker-compose up

# Test
docker-compose run web npm test
```
